# self_delete.py
import os

# do anything
print("bye bye world!")

os.remove(__file__)
