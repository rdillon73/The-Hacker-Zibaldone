# get_input.py
import sys

# Get the input string parameter
input_string = sys.argv[1]

# Print the input string parameter
print(f"Input string parameter: {input_string}")
